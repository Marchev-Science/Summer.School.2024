
import numpy as np

np.random.seed(seed=0)

# A random vector of inputs - dimension 3, where each element is in interval {0,1} (e.g. for example [1,0, 1])
I = np.random.choice([0,1], 3)

# A random vector of inputs - dimension 3, where each element is in interval {-1,1} (e.g. for example [-1, 1, 0])
W = np.random.choice([-1,1], 3)

print(f'Input vector:{I}, Weight vector:{W}')

dot = I @ W
print(f'Dot product: {dot}')

def linear_threshold_gate(dot: int, T: float) -> int:
    '''Returns the binary threshold output'''
    if dot >= T:
        return 1
    else:
        return 0

T = 1
activation = linear_threshold_gate(dot, T)
print(f'Activation: {activation}')

T = 3
activation = linear_threshold_gate(dot, T)
print(f'Activation: {activation}')


# I want to watch a movie where both Francis Ford Copola and Marlon Brando are involved
#                       FFC               MB
# All about Barbie       0                0
# Last tango in Paris    0                1
# Apocalypse Now         1                1
# The Godfather II       1                0

# matrix of inputs
input_table = np.array([
    [0,0], # both no
    [0,1], # no, yes
    [1,1], # yes, yes
    [1,0]  # yes no
])

print(f'input table:\n{input_table}')


# array of weights - check out the picture!!!!!
weights = np.array([1,1])
print(f'weights: {weights}')

# dot product matrix of inputs and weights
dot_products = input_table @ weights
print(f'Dot products: {dot_products}')

T = 2
for i in range(0,4):
    activation = linear_threshold_gate(dot_products[i], T)
    print(f'Activation: {activation}')

# How about the OR function?


